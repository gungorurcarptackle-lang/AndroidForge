# Güngörür Carp Tackle Android APK Projesi

Bu proje v18 HTML panelini Android WebView uygulamasına dönüştürmek için hazırlanmıştır.

## Android Studio ile APK oluşturma
1. Android Studio'yu açın.
2. `GungorurCarpTackleAPK` klasörünü **Open** ile açın.
3. Gradle senkronizasyonunun tamamlanmasını bekleyin.
4. **Build > Build APK(s)** seçin.
5. Oluşan APK'yı Android telefona kurun.

Uygulama internet gerektirmeden çalışacak şekilde hazırlanmıştır. Veriler HTML tarafındaki localStorage üzerinden cihazda tutulur.

Not: Bu sohbet ortamında Android SDK/Gradle derleme zinciri bulunmadığından burada imzalı `.apk` binary'si derlenmedi; Android Studio projesi hazırlandı.
