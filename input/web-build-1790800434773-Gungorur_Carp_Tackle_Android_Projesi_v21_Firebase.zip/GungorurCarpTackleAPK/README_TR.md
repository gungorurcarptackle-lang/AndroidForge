# Güngörür Carp Tackle Android APK Projesi

Bu proje v18 HTML panelini Android WebView uygulamasına dönüştürmek için hazırlanmıştır.

## Android Studio ile APK oluşturma
1. Android Studio'yu açın.
2. `GungorurCarpTackleAPK` klasörünü **Open** ile açın.
3. Gradle senkronizasyonunun tamamlanmasını bekleyin.
4. **Build > Build APK(s)** seçin.
5. Oluşan APK'yı Android telefona kurun.

Uygulama internet gerektirmeden çalışacak şekilde hazırlanmıştır. Veriler HTML tarafındaki localStorage üzerinden cihazda tutulur.

Not: Bu sohbet ortamında Android SDK/Gradle derleme zinciri bulunmadığından burada imzalı `.apk` binary'si derlenmedi; Android Studio projesi hazırlandı.


## Firebase v21 notu
Bu sürüm WebView içindeki yönetim paneline Firebase Authentication + Cloud Firestore bağlantısı ekler.
- E-posta/şifre ile giriş ve müşteri hesabı oluşturma vardır.
- Firestore `users/{uid}` içindeki `role: "admin"` hesabı yönetim panelini açar.
- Diğer kullanıcılar müşteri mağazasını görür.
- Admin tarafındaki mevcut localStorage ürün/stok kayıtları korunur ve `products` koleksiyonuna (yalnızca kod, ad, stok, satış fiyatı) senkronlanır.
- Müşteriler stokta olan ürünleri sepete ekleyip `carts` koleksiyonuna gönderebilir.
- Alış maliyeti müşteriye gönderilmez.
- Firebase Firestore Rules'ın ayrıca Firebase Console'da ayarlanması gerekir.
