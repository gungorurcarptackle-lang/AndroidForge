package com.gungorurcarptackle.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.*;
import com.google.firebase.firestore.*;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private LinearLayout root;
    private WebView web;
    private EditText email, pass, name;
    private TextView status;
    private boolean signup=false;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        FirebaseOptions options = new FirebaseOptions.Builder()
                .setApiKey("AIzaSyAG8qnvNIPQEJCOdE7s75mBwo6PN")
                .setApplicationId("1:60461543441:android:898287f31a6e63d426c1b0")
                .setProjectId("gtcarp-69e0b")
                .setStorageBucket("gtcarp-69e0b.firebasestorage.app")
                .build();
        FirebaseApp app = FirebaseApp.getApps(this).stream()
                .filter(a -> a.getName().equals("gtcarp_manual"))
                .findFirst().orElse(null);
        if (app == null) app = FirebaseApp.initializeApp(this, options, "gtcarp_manual");
        auth=FirebaseAuth.getInstance(app);
        db=FirebaseFirestore.getInstance(app);
        showLogin();
    }

    private TextView tv(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.WHITE); return t; }
    private GradientDrawable bg(int c,float r){ GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(r);return g; }

    private void showLogin(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(40,60,40,40); root.setGravity(Gravity.CENTER_HORIZONTAL); root.setBackgroundColor(Color.rgb(18,18,18));
        TextView logo=tv("GTC\nGungorur Carp Tackle",28); logo.setGravity(Gravity.CENTER); logo.setTypeface(null,1); root.addView(logo,new LinearLayout.LayoutParams(-1,0,1));
        name=new EditText(this); name.setHint("Ad Soyad"); name.setTextColor(Color.WHITE); name.setHintTextColor(Color.GRAY); name.setSingleLine(); root.addView(name,new LinearLayout.LayoutParams(-1,60));
        email=new EditText(this); email.setHint("E-posta"); email.setInputType(33); email.setTextColor(Color.WHITE); email.setHintTextColor(Color.GRAY); email.setSingleLine(); root.addView(email,new LinearLayout.LayoutParams(-1,60));
        pass=new EditText(this); pass.setHint("Şifre"); pass.setInputType(129); pass.setTextColor(Color.WHITE); pass.setHintTextColor(Color.GRAY); pass.setSingleLine(); root.addView(pass,new LinearLayout.LayoutParams(-1,60));
        Button action=new Button(this); action.setText("Giriş Yap"); root.addView(action,new LinearLayout.LayoutParams(-1,60));
        Button toggle=new Button(this); toggle.setText("Yeni hesap oluştur"); root.addView(toggle,new LinearLayout.LayoutParams(-1,60));
        status=tv("",14); status.setGravity(Gravity.CENTER); root.addView(status,new LinearLayout.LayoutParams(-1,70));
        name.setVisibility(View.GONE);
        action.setOnClickListener(v->{ if(signup) doSignup(); else doLogin(); });
        toggle.setOnClickListener(v->{ signup=!signup; name.setVisibility(signup?View.VISIBLE:View.GONE); action.setText(signup?"Hesap Oluştur":"Giriş Yap"); toggle.setText(signup?"Giriş ekranına dön":"Yeni hesap oluştur"); });
        setContentView(root);
    }
    private void msg(String s){ runOnUiThread(()->status.setText(s)); }
    private void doLogin(){ String e=email.getText().toString().trim(),p=pass.getText().toString(); if(e.isEmpty()||p.isEmpty()){msg("E-posta ve şifre gerekli.");return;} msg("Giriş yapılıyor..."); auth.signInWithEmailAndPassword(e,p).addOnCompleteListener(t->{ if(t.isSuccessful()) openApp(); else msg("Giriş başarısız: "+(t.getException()!=null?t.getException().getMessage():"Bilinmeyen hata")); }); }
    private void doSignup(){ String n=name.getText().toString().trim(),e=email.getText().toString().trim(),p=pass.getText().toString(); if(n.isEmpty()||e.isEmpty()||p.length()<6){msg("Ad, e-posta ve en az 6 karakter şifre gerekli.");return;} msg("Hesap oluşturuluyor..."); auth.createUserWithEmailAndPassword(e,p).addOnCompleteListener(t->{ if(!t.isSuccessful()){msg("Kayıt başarısız: "+(t.getException()!=null?t.getException().getMessage():"Bilinmeyen hata"));return;} String uid=auth.getCurrentUser().getUid(); Map<String,Object> u=new HashMap<>();u.put("name",n);u.put("email",e);u.put("role","customer");u.put("createdAt",FieldValue.serverTimestamp());db.collection("users").document(uid).set(u).addOnSuccessListener(x->openApp()).addOnFailureListener(x->msg("Kullanıcı oluşturuldu fakat profil kaydedilemedi: "+x.getMessage())); }); }

    private void openApp(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(36,60,36,36); root.setGravity(Gravity.CENTER_HORIZONTAL); root.setBackgroundColor(Color.WHITE);
        TextView title=new TextView(this); title.setText("GTC\nGungorur Carp Tackle"); title.setTextSize(30); title.setTypeface(null,1); title.setTextColor(Color.BLACK); title.setGravity(Gravity.CENTER); root.addView(title,new LinearLayout.LayoutParams(-1,0,1));
        TextView ok=new TextView(this); ok.setText("FIREBASE NATIVE AKTİF"); ok.setTextSize(22); ok.setTypeface(null,1); ok.setTextColor(Color.rgb(30,120,70)); ok.setGravity(Gravity.CENTER); root.addView(ok,new LinearLayout.LayoutParams(-1,80));
        TextView info=new TextView(this); info.setTextSize(16); info.setTextColor(Color.DKGRAY); info.setGravity(Gravity.CENTER); root.addView(info,new LinearLayout.LayoutParams(-1,0,1));
        Button logout=new Button(this); logout.setText("Çıkış Yap"); root.addView(logout,new LinearLayout.LayoutParams(-1,64));
        logout.setOnClickListener(v->{auth.signOut();showLogin();});
        setContentView(root);
        if(auth.getCurrentUser()!=null){
            String uid=auth.getCurrentUser().getUid(); String em=auth.getCurrentUser().getEmail();
            db.collection("users").document(uid).get().addOnSuccessListener(doc->{
                String role=doc.exists()?String.valueOf(doc.get("role")):"customer";
                String n=doc.exists()?String.valueOf(doc.get("name")):"";
                info.setText("Giriş başarılı\n\nAd: "+n+"\nE-posta: "+em+"\nRol: "+role+"\n\nFirebase Auth + Firestore bağlantısı çalışıyor.");
            }).addOnFailureListener(e->info.setText("Firebase Auth çalışıyor.\nFirestore bağlantı hatası: "+e.getMessage()));
        }
    }

    public class AndroidBridge{
        @JavascriptInterface public String uid(){return auth.getCurrentUser()!=null?auth.getCurrentUser().getUid():"";}
        @JavascriptInterface public String email(){return auth.getCurrentUser()!=null?auth.getCurrentUser().getEmail():"";}
        @JavascriptInterface public void logout(){runOnUiThread(()->{auth.signOut();showLogin();});}
        @JavascriptInterface public void loadCloud(){
            if(auth.getCurrentUser()==null)return; String uid=auth.getCurrentUser().getUid();
            db.collection("users").document(uid).get().addOnSuccessListener(doc->{String role=doc.exists()?String.valueOf(doc.get("role")):"customer";String n=doc.exists()?String.valueOf(doc.get("name")):"";runOnUiThread(()->web.evaluateJavascript("window.onNativeSession && window.onNativeSession("+q(role)+","+q(n)+","+q(uid)+");",null));});
        }
        private String q(String x){return "'"+x.replace("\\","\\\\").replace("'","\\'")+"'";}
    }
}
