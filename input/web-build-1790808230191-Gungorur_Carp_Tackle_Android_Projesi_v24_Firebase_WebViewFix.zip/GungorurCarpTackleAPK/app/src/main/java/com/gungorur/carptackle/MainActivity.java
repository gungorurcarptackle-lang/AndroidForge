package com.gungorur.carptackle;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MainActivity extends Activity {
    private static final String FILE_URL = "file:///android_asset/index.html";
    private static final String HTTPS_BASE = "https://gtcarp-69e0b.firebaseapp.com/";
    private static final String PREFS = "gtcarp_migration";
    private static final String STORAGE = "migrated_local_storage";
    private static final String DONE = "migration_done";

    private WebView webView;
    private SharedPreferences prefs;
    private boolean migrating = false;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(false);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (!prefs.getBoolean(DONE, false) && !migrating && url.startsWith(FILE_URL)) {
                    migrating = true;
                    view.evaluateJavascript(
                        "(function(){var o={};for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);o[k]=localStorage.getItem(k);}return JSON.stringify(o);})()",
                        value -> {
                            try {
                                Object parsed = new JSONTokener(value).nextValue();
                                String json = parsed instanceof String ? (String) parsed : "{}";
                                prefs.edit().putString(STORAGE, json).putBoolean(DONE, true).apply();
                                loadHttpsApp();
                            } catch (Exception e) {
                                migrating = false;
                            }
                        }
                    );
                }
            }
        });

        if (prefs.getBoolean(DONE, false)) {
            loadHttpsApp();
        } else {
            webView.loadUrl(FILE_URL);
        }
    }

    private void loadHttpsApp() {
        try {
            String html = readAsset("index.html");
            webView.loadDataWithBaseURL(HTTPS_BASE, html, "text/html", "UTF-8", HTTPS_BASE);
        } catch (Exception e) {
            webView.loadUrl(FILE_URL);
        }
    }

    private String readAsset(String name) throws Exception {
        StringBuilder sb = new StringBuilder();
        BufferedReader br = new BufferedReader(new InputStreamReader(getAssets().open(name), "UTF-8"));
        String line;
        while ((line = br.readLine()) != null) sb.append(line).append('\n');
        br.close();
        return sb.toString();
    }

    private class AndroidBridge {
        @JavascriptInterface
        public String getMigratedStorage() {
            return prefs.getString(STORAGE, "");
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
